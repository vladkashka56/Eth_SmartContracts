## AirNFT-ERC721

The solidity project files for the AirNFT custom ERC721 contract.

Can be verified as well on https://bscscan.com/address/0xf5db804101d8600c26598a1ba465166c33cdaa4b#code

