./node_modules/.bin/truffle-flattener contracts/Creature.sol > flattened/Creature.sol
./node_modules/.bin/truffle-flattener contracts/CreatureFactory.sol > flattened/CreatureFactory.sol
./node_modules/.bin/truffle-flattener contracts/CreatureLootBox.sol > flattened/CreatureLootBox.sol
./node_modules/.bin/truffle-flattener contracts/CreatureAccessory.sol > flattened/CreatureAccessory.sol
./node_modules/.bin/truffle-flattener contracts/CreatureAccessoryFactory.sol > flattened/CreatureAccessoryFactory.sol
./node_modules/.bin/truffle-flattener contracts/CreatureAccessoryLootBox.sol > flattened/CreatureAccessoryLootBox.sol
